import * as Icons from 'lucide-react';

export const LucideIcon: { [key: string]: Icons.LucideIcon } = Icons;